<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Madruga's Barber</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Cabeçalho -->
    <header>
        <div class="logo">
            <img src="logo.png" alt="Madruga's Barber Logo">
        </div>
        <nav>
            <a href="sobre_nos.html">Sobre Nós</a>
            <a href="#contato">Contate-nos</a>
        </nav>
    </header>

    <!-- Seção Trabalhos -->
    <section id="trabalhos">
        <h2>Alguns dos nossos trabalhos</h2>
        <div class="galeria">
            <div class="imagem">
                <img src="corte1.jpg" alt="Corte Miguel">
                <p>Miguel</p>
            </div>
            <div class="imagem">
                <img src="corte2.jpg" alt="Corte Mateus">
                <p>Mateus</p>
            </div>
            <div class="imagem">
                <img src="corte3.jpg" alt="Corte Yuri">
                <p>Yuri</p>
            </div>
        </div>
    </section>

    <!-- Seção Sobre Nós -->
    <section id="sobre-nos">
        <h2>Sobre Nós</h2>
        <p>A Madruga's Barber é uma barbearia localizada em Diadema, no bairro Serraria, especializada em cortes de cabelo...</p>
    </section>

    <!-- Seção Créditos -->
    <section id="creditos">
        <h2>Créditos</h2>
        <ul>
            <li>Administração: David Peterson, Flávio José, Gustavo Figueiredo...</li>
            <li>Desenvolvimento: Cauã Lopes, Fernando Sousa, José Igor...</li>
        </ul>
    </section>

    <!-- Rodapé -->
    <footer>
        <p>&copy; 2024 Madruga's Barber. Todos os direitos reservados.</p>
    </footer>
</body>
</html>