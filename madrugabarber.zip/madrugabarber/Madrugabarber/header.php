<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Madruga's Barber</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="imagens/logo.svg" alt="Madruga's Barber Logo" class="logo">
        </div>
        <nav>
            <a href="#sobre-nos">Sobre Nós</a>
            <a href="#contato">Contate-nos</a>
        </nav>
    </header>