<footer>
        <p>&copy; 2024 Madruga's Barber. Todos os direitos reservados.</p>
    </footer>
</body>
</html>